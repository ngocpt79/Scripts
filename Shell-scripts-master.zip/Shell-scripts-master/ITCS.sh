## for ITCS104 quarterly audit automation
#!/bin/sh
## ssh-keygen -t rsa ## incase dont have pub/priv key
####add key to hosts###
#cat /home/ngoc/.ssh/id_rsa.pub | ssh ngoc@$host "mkdir -p /home/ngoc/.ssh && chmod 700 /home/ngoc/.ssh && cat >> /home/ngoc/.ssh/authorized_keys"
#SERVERS="/home/ngoc/servers.txt"
for host in $(cat /home/ngoc/servers.txt);
do
    echo "### Result for $host ###"
    ssh $host '/usr/local/bin/sudo -S /home/ngoc/audit.sh >> /home/ngoc/result.txt && /usr/local/bin/sudo -S /home/ngoc/audit1.sh >> /home/ngoc/result.txt'
    scp ngoc@$host:/home/ngoc/result.txt /home/ngoc/
    ssh $host '/usr/local/bin/sudo -S rm -rf /home/ngoc/result.txt'
    cat /home/ngoc/result.txt >> /home/ngoc/ITCS/$host.txt
    cat /home/ngoc/result.txt >> /home/ngoc/ITCS/ITCS.txt
    rm -rf /home/ngoc/result.txt
done 
/usr/bin/mail -s "ITCS104" ngoc.trong.phan@ibm.com < /home/ngoc/ITCS/ITCS.txt