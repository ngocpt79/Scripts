#!/bin/sh
## for del user from aix servers in aix.txt
## dulla
for host in $(cat /home/ngoc/aix.txt);
do
        echo "### Check ssh connection to $host ###"
        status=$(ssh -o BatchMode=yes -o ConnectTimeout=10 $host echo ok 2>&1)
        if [[ $status == *"IBM"* ]] ; then
             echo "### Remove user from $host ###"
            ssh $host '/usr/local/bin/sudo -S /usr/sbin/userdel -r dulla'
        else
        echo "can not connect to $host"
        fi
done 

