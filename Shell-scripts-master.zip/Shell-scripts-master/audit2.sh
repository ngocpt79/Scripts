#!/bin/sh

find / /usr /var /etc /bin /usr/bin /usr/sbin /usr/etc /var/adm -prune -perm -o+rx
echo '################################################ locks'
ls -al /etc/locks
echo '################################################ security'
ls -al /etc/security
echo '################################################ tmp'
ls -al /tmp
echo '################################################'
grep -E "root|daemon|bin|sys|adm|uucp|nuucp|lpd|imnadm|ipsec|ldap|lp|snapp|invscout|pconsole|esaadmin" /etc/passwd
echo '################################################'
grep -E "haemrm|snapp|hacmp|pconsole" /etc/group
echo '################################################'
cat /etc/inittab | grep rc
echo '################################################'
cat /etc/ftpusers
echo '################################################'
ls -al /var/adm/wtmp
ls -al /var/adm/sulog
ls -al /etc/security/failedlogin
echo '################################################ syslog'
cat /etc/syslog.conf | grep auth
echo '################################################'
ls -al /etc/tftpaccess.ctl
ps -ef | grep ftp
echo '################################################ host equiv'
cat /etc/hosts.equiv
echo '################################################'
ps -ef | grep rexd
ps -ef | grep bsh
cat /var/ifor/i4ls.ini | grep DisableRemoteAdmin
echo '################################################ i4ls'
ls -al /var/ifor/i4ls.ini
echo '################################################'
cat /etc/inetd.conf
echo '################################################ yppasswd':
ps -ef | grep yppasswd
ps -ef | grep ftp
ps -ef | grep nfs
ls /etc/exports