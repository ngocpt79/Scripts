#!/bin/ksh

# Log for sending email out
LOG=/tmp/pwage.log
/usr/bin/cat /dev/null > $LOG

# Get last password changed date
lastchanged=`/usr/bin/pwdadm -q ibmsec | grep lastupdate | cut -d "=" -f2 | /bin/bc`
changed_date=`/usr/bin/perl -leprint\ scalar\ localtime\ $lastchanged`

# Calculate expired date

expired=`/usr/bin/echo $lastchanged+(60*60*24*90) | /bin/bc `
expired_date=`/usr/bin/perl -leprint\ scalar\ localtime\ $expired`
now=`date -u +%s`
expiredin=`/usr/bin/echo $expired - $now | /bin/bc`

# Compute the remaining days of the user's password
remain=`/usr/bin/echo $expiredin/86400 | /bin/bc`

# Compute and display the number of days until password expiration
/usr/bin/echo "Ibmsec's password will be expired on $expired_date only $remain days left" >> $LOG
/usr/bin/echo "Ibmsec last changed password is on $changed_date" >> $LOG
/usr/bin/echo "Please check sazcit1/2 sazbiz1/2 ebizdbs ebizsnfs ebizivr1 and other servers for updating ibmsec password asap" >> $LOG

if [ $remain -lt 8 ]
    then
        #/usr/bin/mail -s "Ibmsec password will be expired in next $remain days" ngoc.trong.phan@ibm.com < $LOG
        /usr/bin/mail -s "Ibmsec password will be expired in next $remain days" ngoc.trong.phan@ibm.com,ops@clearlake.ibm.com,alextrinh@us.ibm.com < $LOG
fi
