#!/bin/sh
## for adding new user to aix servers locally
mkuser -a admin='false' pgrp='staff' groups='staff' home='/home/sjordan' shell='/usr/bin/ksh' gecos='Samuel Jordan/////sjordan@us.ibm.com' sjordan &&
echo "sjordan:new1pass" | chpasswd &&
sed 's/SYSADMIN = .*/&, sjordan/g' /etc/sudoers > /etc/sudoers.tmp &&
cp /etc/sudoers /etc/sudoers.bk &&
mv /etc/sudoers.tmp /etc/sudoers &&
chmod 440 /etc/sudoers && 
sed 's/:\./:\/usr\/local\/bin:./g' /home/sjordan/.profile > /home/sjordan/.profile.tmp &&
mv /home/sjordan/.profile.tmp /home/sjordan/.profile &&
chown sjordan.staff /home/sjordan/.profile &&
chmod 700 /home/sjordan/.profile &&
cat /etc/sudoers | grep sjordan;

#for Duo needed server smtp/mon05/tiv9

mkuser -a admin='false' pgrp='staff' groups='staff, twofact' home='/home/sjordan' shell='/usr/bin/ksh' gecos='Samuel Jordan/////sjordan@us.ibm.com' sjordan &&
echo "sjordan:new1pass" | chpasswd &&
sed 's/SYSADMIN = .*/&, sjordan/g' /etc/sudoers > /etc/sudoers.tmp &&
cp /etc/sudoers /etc/sudoers.bk &&
mv /etc/sudoers.tmp /etc/sudoers &&
chmod 440 /etc/sudoers && 
sed 's/:\./:\/usr\/local\/bin:./g' /home/sjordan/.profile > /home/sjordan/.profile.tmp &&
mv /home/sjordan/.profile.tmp /home/sjordan/.profile &&
chown sjordan.staff /home/sjordan/.profile &&
chmod 700 /home/sjordan/.profile &&
cat /etc/sudoers | grep sjordan;
sadsa