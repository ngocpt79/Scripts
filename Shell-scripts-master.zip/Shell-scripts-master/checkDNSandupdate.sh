#!bin/sh
file=test
oldserial=`egrep -ho "2018[0-9]*" /var/named/download.vng.com.vn.db`
newserial=$(($oldserial + 1))
file=/var/named/download.vng.com.vn.db
for ipaddr in $(cat /usr/runscript/ipaddress)
	do
		alive=$(wget $ipaddr -q -O -)
		if [ -n "$alive" ]; then
			echo "$ipaddr isup"
			while read line
			do
				temp=$(echo "$line" | awk '{print $1,$3}')
				if [ "$temp" = ";IN $ipadr" ]; then
					sed -i "s/;IN	A	$ipaddr/	IN	A	$ipaddr/g" /var/named/download.vng.com.vn.db
					sed -i "s/$oldserial/$newserial/g" /var/named/download.vng.com.vn.db
					/etc/init.d/named reload
				fi
			done<$file
		else
			echo "$ipaddr isdown"
			while read line
                        do
                                temp=$(echo "$line" | awk '{print $1,$3}')
                                if [ "$temp" = "IN $ipaddr" ]; then
					sed -i "s/	IN	A	$ipaddr/;IN	A	$ipaddr/g" /var/named/download.vng.com.vn.db
					sed -i "s/$oldserial/$newserial/g" /var/named/download.vng.com.vn.db
					/etc/init.d/named reload
				fi
			done<$file
		fi
	done
