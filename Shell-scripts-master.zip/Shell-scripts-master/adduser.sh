#!/bin/sh
## for add new user to aix servers in aix.txt
## sjordan as sysadmin
for host in $(cat /home/ngoc/aix.txt);
do
    echo "### Check ssh connection to $host ###"
    status=$(ssh -o BatchMode=yes -o ConnectTimeout=10 $host echo ok 2>&1)
    if [[ $status == *"IBM"* ]] ; then
        echo "### Add user to $host ###"
        ssh -t $host'
            /usr/local/bin/sudo su
            /usr/bin/mkuser -a admin='false' pgrp='staff' groups='staff' home='/home/sjordan' shell='/usr/bin/ksh' gecos='Samuel Jordan III/Houston/IBM' sjordan
            /usr/bin/echo "user sjordan added successfully!"
            /usr/bin/echo -e "new1pass:new1pass" | /usr/bin/passwd sjordan
            /usr/bin/echo "Password for user $i changed successfully"
            /usr/bin/sed 's/SYSADMIN= .*/& , sjordan/g' /etc/sudoers > /etc/sudoers.n
            /usr/bin/cp /etc/sudoers /etc/sudoers.bk
            /usr/bin/mv /etc/sudoers.n /etc/sudoers
            /usr/bin/chmod 440 /etc/sudoers
    else
        echo "can not connect to $host"
    fi
done 