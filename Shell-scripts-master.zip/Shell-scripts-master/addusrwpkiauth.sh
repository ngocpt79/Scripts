#!/bin/sh
useradd $1
mkdir -p /home/$1/.ssh
chown -R $1.$1 /home/$1/
vi /home/$1/.ssh/authorized_keys ;chown -R $1.$1 /home/$1/;


#ssh without keyasking add key to auth key
#!/bin/bash
ssh-keygen -t rsa
ssh root@$1 mkdir -p .ssh
cd /root
cat .ssh/id_rsa.pub | ssh  root@$1  'cat >> .ssh/authorized_keys'

# run that command
## sshwithoutpass.sh ip port
kill $(ps aux | grep 'process name with regex' | awk '{print $2}')