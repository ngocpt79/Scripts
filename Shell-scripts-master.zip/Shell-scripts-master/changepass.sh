#!/bin/sh
## for change password user from aix servers in aix.txt
## ibmsec
for host in $(cat /home/ngoc/aix.txt);
do
        echo "### Check ssh connection to $host ###"
        status=$(ssh -o BatchMode=yes -o ConnectTimeout=10 $host echo ok 2>&1)
        if [[ $status == *"IBM"* ]] ; then
             echo "### Change password user from $host ###"
            #ssh $host "/usr/local/bin/sudo su; echo -e '1BM@sec!\n1BM@sec!' | passwd ibmsec;"
            ssh $host "/usr/local/bin/sudo -S echo ibmsec:1BM@sec! | chpasswd"
        else
        echo "can not connect to $host"
        fi
done 
