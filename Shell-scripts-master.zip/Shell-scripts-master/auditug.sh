#!/bin/sh
#for audit user, group profile

sort /etc/passwd | uniq -c
echo '################################################'
sort /etc/group | uniq -c
echo '################################################'
cat /etc/security/user | grep "maxage =" 
cat /etc/security/user | grep "minage =" 
cat /etc/security/user | grep "minalpha ="
cat /etc/security/user | grep "minother ="
cat /etc/security/user | grep "minlen ="
cat /etc/security/user | grep "histsize ="
echo '################################################'
cat /etc/security/passwd | grep NOCHECK
ls /usr/share/dict/words
echo '############################################### sha check'
cat /etc/security/login.cfg | grep sha
cat /etc/security/passwd
echo '################################################'
cat /etc/security/user | grep "login ="
cat /etc/security/user | grep "rlogin ="
echo '################################################ ftpusers'
cat /etc/ftpusers
echo '################################################'
cat /etc/motd
echo '################################################'
cat /etc/security/user | grep "umask ="